package programs;

import java.util.Scanner;

public class ColorGenerator {

	public static void main(String[] args) {
		Scanner color = new Scanner(System.in);

		String red;
		String greenBlue;

		System.out.print("Do you want red? (Yes/Yeah/No): ");
		red = color.next();

		System.out.print("Do you want green and blue? (Yes/Yeah/No): ");
		greenBlue = color.next();

		if ((red .equals ("Yes") || red .equals ("Yeah")) && ((!greenBlue .equals ("Yes") &&
				!greenBlue .equals ("Yeah")))) {
			System.out.print(" Final Color: #FF0000");
		}

		else if ((!red .equals ("Yes") && !red .equals ("Yeah")) && (greenBlue .equals ("Yes") ||
				greenBlue .equals ("Yeah"))) {
			System.out.print(" Final Color: #00FFFF");
		} 
		
		else if ((red .equals ("Yes") || red .equals ("Yeah")) && (greenBlue .equals ("Yes") ||
				greenBlue .equals ("Yeah"))) {
			System.out.print(" Final Color: #FFFFFF");
		}
		
		else {
			System.out.print(" Final Color: #000000");
		}

		color.close();

	}

}
