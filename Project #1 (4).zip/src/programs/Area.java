package programs;
import java.util.Scanner;

public class Area {

	public static void main(String[] args) {
		Scanner triangle = new Scanner (System.in);
		
		//input holders
		
		float base;
		float height;
		float area;
		
		//input and text
		
		System.out.print("Enter base: ");
		base = triangle.nextInt();
		
		System.out.print("Enter height: ");
		height = triangle.nextInt();
		
		area = (base * height)/2;
		
		System.out.print("Area is: " + area);
		
		
		triangle.close();
		
		
	
	}
}